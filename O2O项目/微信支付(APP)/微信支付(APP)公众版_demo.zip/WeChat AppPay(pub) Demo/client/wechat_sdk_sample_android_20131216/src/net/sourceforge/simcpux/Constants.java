package net.sourceforge.simcpux;

public class Constants {
	// APP_ID �滻Ϊ���Ӧ�ôӹٷ���վ���뵽�ĺϷ�appId
    public static final String APP_ID = "wxd930ea5d5a258f4f";
    
    /** �̼���Ƹ�ͨ������̼�id */
    public static final String PARTNER_ID = "1900000109";
    
    public static class ShowMsgActivity {
		public static final String STitle = "showmsg_title";
		public static final String SMessage = "showmsg_message";
		public static final String BAThumbData = "showmsg_thumb_data";
	}
}
