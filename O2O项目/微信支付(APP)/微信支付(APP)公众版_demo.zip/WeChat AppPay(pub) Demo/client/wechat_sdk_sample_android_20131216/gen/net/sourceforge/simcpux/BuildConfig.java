/** Automatically generated file. DO NOT MODIFY */
package net.sourceforge.simcpux;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}