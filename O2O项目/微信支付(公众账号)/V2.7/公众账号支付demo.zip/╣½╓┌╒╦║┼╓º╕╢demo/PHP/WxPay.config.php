<?php
/**
* 
*/

define(APPID , "");  //appid
define(APPKEY ,""); //paysign key
define(SIGNTYPE, "sha1"); //method
define(PARTNERKEY,"");//通加密串
define(APPSERCERT, "");

?>